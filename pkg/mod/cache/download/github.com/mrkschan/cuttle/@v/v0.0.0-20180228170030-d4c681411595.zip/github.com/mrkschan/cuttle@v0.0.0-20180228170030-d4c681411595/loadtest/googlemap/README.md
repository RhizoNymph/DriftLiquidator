Run
---

```
https_proxy=127.0.0.1:3128 API_KEY=YOUR_API_KEY ./load.rb
```


Expected
--------

No WARN print to stderr.
