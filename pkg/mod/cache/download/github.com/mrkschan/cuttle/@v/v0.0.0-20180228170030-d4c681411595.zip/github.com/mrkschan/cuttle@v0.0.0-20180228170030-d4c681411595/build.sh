#!/bin/bash
GO15VENDOREXPERIMENT=1 go build -o bin/cuttle main.go
