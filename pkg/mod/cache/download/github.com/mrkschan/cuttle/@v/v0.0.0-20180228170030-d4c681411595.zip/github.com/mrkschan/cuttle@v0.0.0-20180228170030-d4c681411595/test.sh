#!/bin/bash
GO15VENDOREXPERIMENT=1 go test ./cuttle/
