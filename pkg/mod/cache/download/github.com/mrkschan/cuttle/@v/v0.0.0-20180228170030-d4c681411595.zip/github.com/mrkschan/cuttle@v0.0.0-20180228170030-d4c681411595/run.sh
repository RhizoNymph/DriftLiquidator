#!/bin/bash
GO15VENDOREXPERIMENT=1 go run main.go
